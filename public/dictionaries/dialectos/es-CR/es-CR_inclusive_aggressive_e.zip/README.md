# Español Inclusivo - es-CR (Reemplazo, -e)

Diccionario con términos inclusivos en español para es-CR, usando -e como marcador

Contiene 50701 palabras.

## Uso

Este diccionario puede usarse con correctores ortográficos que soportan formato JSON o Hunspell.

## Licencia

Este diccionario se distribuye bajo la misma licencia que el diccionario original, con modificaciones para inclusividad.
