# Español Inclusivo - es_ES (Reemplazo, -e)

Diccionario con términos inclusivos en español para es_ES, usando -e como marcador

Contiene 66610 palabras.

## Uso

Este diccionario puede usarse con correctores ortográficos que soportan formato JSON o Hunspell.

## Licencia

Este diccionario se distribuye bajo la misma licencia que el diccionario original, con modificaciones para inclusividad.
