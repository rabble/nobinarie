# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español Inclusivo - es_ES (Reemplazo, -x)

Diccionario con términos inclusivos en español para es_ES, usando -x como marcador

Contiene 69254 palabras.
