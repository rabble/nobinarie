# Español Inclusivo - es-MX (Adición, -x)

Diccionario con términos inclusivos en español para es-MX, usando -x como marcador

Contiene 84761 palabras.

## Uso

Este diccionario puede usarse con correctores ortográficos que soportan formato JSON o Hunspell.

## Licencia

Este diccionario se distribuye bajo la misma licencia que el diccionario original, con modificaciones para inclusividad.
