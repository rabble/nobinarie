# Español Inclusivo - es-PR (Reemplazo, @)

Diccionario con términos inclusivos en español para es-PR, usando @ como marcador

Contiene 51086 palabras.

## Uso

Este diccionario puede usarse con correctores ortográficos que soportan formato JSON o Hunspell.

## Licencia

Este diccionario se distribuye bajo la misma licencia que el diccionario original, con modificaciones para inclusividad.
