# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español Inclusivo

Diccionario con términos inclusivos en español

Contiene 5 palabras.
