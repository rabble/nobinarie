# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español Inclusivo (Adición, -x)

Diccionario con términos inclusivos en español, usando -x como marcador

Contiene 66 palabras.
