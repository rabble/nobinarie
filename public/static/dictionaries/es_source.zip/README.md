# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español

Diccionario español para conversión inclusiva

Contiene 300 palabras.
