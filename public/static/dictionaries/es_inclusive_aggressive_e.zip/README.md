# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español Inclusivo - es (Reemplazo, -e)

Diccionario con términos inclusivos en español para es, usando -e como marcador

Contiene 52104 palabras.
