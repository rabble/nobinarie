# Español Inclusivo - es (Adición, -e)

Diccionario con términos inclusivos en español para es, usando -e como marcador

Contiene 82866 palabras.

## Uso

Este diccionario puede usarse con correctores ortográficos que soportan formato JSON o Hunspell.

## Licencia

Este diccionario se distribuye bajo la misma licencia que el diccionario original, con modificaciones para inclusividad.
