# Diccionario en Español Inclusivo

Este archivo contiene un diccionario en español inclusivo para usar en correctores ortográficos y herramientas lingüísticas.

## Español Inclusivo - es_ES (Reemplazo, @)

Diccionario con términos inclusivos en español para es_ES, usando @ como marcador

Contiene 69255 palabras.
